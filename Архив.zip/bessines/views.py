from django.shortcuts import render

from datetime import datetime
from django.http import HttpRequest, JsonResponse
from django.utils.translation import gettext as _
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import TemplateView, ListView
from django.views import View

from .models import Product


class IndexTemplateView(TemplateView):
    template_name = 'main/index.html'









